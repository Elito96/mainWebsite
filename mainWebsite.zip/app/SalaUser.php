<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalaUser extends Model
{
    protected $table = 'salauser';
    protected $fillable = [
        'sala_id', 'user_id',];
}
