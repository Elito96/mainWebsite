<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChatHistorial extends Model
{
     protected $table = 'chathistorial';
    protected $fillable = [
        'chat_id','user_id','mensaje'];
}
