<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HistorialDiagrama extends Model
{
    protected $table = 'historialdiagrama';
    protected $fillable = [
        'diagrama_id', 'user_id','code',];
}
