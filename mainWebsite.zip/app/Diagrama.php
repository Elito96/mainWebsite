<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Diagrama extends Model
{
    protected $table = 'diagrama';
    protected $fillable = [
        'code'];
}
