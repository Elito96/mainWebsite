<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class busquedaController extends Controller
{
    public function buscar($palabras){

     $parametros = explode("@", $palabras);
     
     if(count($parametros) == 1){	
     	$palabras = $parametros[0];
    	$patterns = array("/\s+/", "/\s([?.!])/");
		$replacer = array(" ","$1");

		# string(44) "This is a dummy text. I need to format this."
		$palabras = preg_replace( $patterns, $replacer, $palabras );
    	$entidades = DB::table('entidades')
                ->where('descripcion', 'like', '%'.$palabras.'%')
                ->select('id')->get();

     if(count($entidades) > 0 ){      
        for ($i=0; $i < count($entidades); $i++) { 
        	$sucursales = DB::table('sucursales')->where([['entidad_id', $entidades[$i]->id], ['habilitada', '1']])->select('*')->orderBy('horaInicioDeAtencion','asc')->get();

        }
        $horariosAbiertos = array();
        $horariosCerrados = array();
        $latitudes = array();
        $longitudes = array();
        for ($i=0; $i <count($sucursales) ; $i++) { 
        	$horariosAbiertos[] = explode(':',$sucursales[$i]->horaInicioDeAtencion);
        	$horariosCerrados[] = explode(':',$sucursales[$i]->horaFinalDeAtencion);
        	$latitudes[] = $sucursales[$i]->latitud;
        	$longitudes[] = $sucursales[$i]->longitud;
        }


        $current = Carbon::now('America/La_Paz');
        $horaActual = $current->hour;
      
        $minutoActual = $current->minute;
        $sucursalesAbiertas = array();
        $sucursalesCerradas = array();
        $nombreEntidades = array();
      
        for ($i=0; $i < count($sucursales); $i++) { 
        	$horarioA = $horariosAbiertos[$i][0].':'. $horariosAbiertos[$i][1];
        	$horarioC = $horariosCerrados[$i][0].':'.$horariosCerrados[$i][1];
        	
        	if($this->estaAbierto($horaActual, $horariosAbiertos[$i][0], $horariosCerrados[$i][0],$minutoActual,$horariosAbiertos[$i][1], $horariosCerrados[$i][1]))
        			$sucursalesAbiertas[] = ['nombre' => DB::table('entidades')->where('id', $sucursales[$i]->entidad_id)->select('nombre')->get()[0]->nombre, 'horarioAbierto' => $horarioA, 'horarioCerrado' => $horarioC, 'latitud' => $latitudes[$i], 'longitud' => $longitudes[$i], 'imagen' => 'abierto.png', 'id' => $i, 'distancia' => '0'];

        	else
        				$sucursalesCerradas[] = ['nombre' => DB::table('entidades')->where('id', $sucursales[$i]->entidad_id)->select('nombre')->get()[0]->nombre, 'horarioAbierto' => $horarioA, 'horarioCerrado' => $horarioC, 'latitud' => $latitudes[$i], 'longitud' => $longitudes[$i], 'imagen' => 'cerrado.png', 'id' => $i, 'distancia' => '0'];
        

        }
        
        return view('mapa',['Abierto' =>$sucursalesAbiertas,'Cerrado' => $sucursalesCerradas, 'resultado' => 'Resultado de: '.$palabras]); 
    }
        
    	 $sucursalesCerradas = array();
    	 $sucursalesAbiertas = array();
    	  return view('mapa',['Abierto' =>$sucursalesAbiertas,'Cerrado' => $sucursalesCerradas, 'resultado' => 'No se hallaron resultados']); 
    	} else
    		return $this->buscarCercanos($parametros[0],$parametros[1],$parametros[2]);
    	

    }
    private function estaAbierto($horaActual, $horaAbierta, $horaCerrado, $minutoActual, $minutoInicio, $minutoFinal){
    	if($horaAbierta > $horaCerrado){
    		$nuevoCerrado = 23 + $this->encontrarIndex($horaCerrado);
    		if ($horaAbierta > $horaActual) {
    			$nuevaHoraActual = 23 + $this->encontrarIndex($horaActual);
    			if($nuevaHoraActual < $nuevoCerrado)
    				return true;
    			else
    				if ($nuevaHoraActual == $nuevoCerrado){
    					if($minutoActual < $minutoFinal)
    						return true;
    				}
    		} else {
    			if($horaActual > $horaAbierta){
    					return true;
    			} else
    				if ($horaActual == $horaAbierta) {
    					if($minutoActual >= $minutoInicio)
    						return true;
    				}
    		}
    	} else{
    		if($horaAbierta >= $horaActual && $horaActual <= $horaCerrado){
    			if($horaActual == $horaAbierta)
    				if($minutoActual >= $minutoInicio)
    					return true;
    			if($horaActual == $horaCerrado)
    				if($minutoActual < $minutoFinal)
    				  return true;	
    		}
    	}
    	
    	return false;
    	

    	$distAA = $this->distanciaEntre($horaAbierta, $horaActual);
    	$distAC = $this->distanciaEntre($horaAbierta, $horaCerrado);
    	$distACC = $this->distanciaEntre($horaActual, $horaCerrado);
    	if($distAA <$distAC){
    		if($distAA == 0 && $minutoActual >= $minutoInicio)
    			return true;
    		else
                   if($distACC == 0 && $minutoActual < $minutoFinal)
    			return true;
    	}
    	return false;

    	
    }
    private function encontrarIndex($h){
    	$index = 0;
    	for ($i=0; $i < 24 ; $i++) { 
    		if($i == $h)
    			return $index+1;
    		$index++;
    	}
    	return $index+1;
    }
    public function search(){
    	return $this->buscarCercanos($_POST['src'],$_POST['latitude'], $_POST['longitude']);
    }
    private function distanciaEntre($a, $b){
    	$dis = 0;
    	for ($i=0; $i <24 ; $i++) { 
    		if($a == $b)
    			return $dis;
    		$a = ($a + 1) % 24;
    		$dis++;

    	}
    	return $dis;
    }
    public function buscarCercanos($palabras, $lat, $lng){
    	$patterns = array("/\s+/", "/\s([?.!])/");
		$replacer = array(" ","$1");

		# string(44) "This is a dummy text. I need to format this."
		$palabras = preg_replace( $patterns, $replacer, $palabras );
    	$entidades = DB::table('entidades')
                ->where('descripcion', 'like', '%'.$palabras.'%')
                ->select('id')->get();

     if(count($entidades) > 0 ){      
        for ($i=0; $i < count($entidades); $i++) { 
        	$sucursales = DB::table('sucursales')->where([['entidad_id', $entidades[$i]->id], ['habilitada', '1']])->select('*')->orderBy('horaInicioDeAtencion','asc')->get();

        }
        $horariosAbiertos = array();
        $horariosCerrados = array();
        $latitudes = array();
        $longitudes = array();
        $distancias = array();
        for ($i=0; $i <count($sucursales) ; $i++) { 
        	$horariosAbiertos[] = explode(':',$sucursales[$i]->horaInicioDeAtencion);
        	$horariosCerrados[] = explode(':',$sucursales[$i]->horaFinalDeAtencion);
        	$latitudes[] = $sucursales[$i]->latitud;
        	$longitudes[] = $sucursales[$i]->longitud;
        	$distancias[] = $this->getDistanceInMetersTo($lat,$lng, $sucursales[$i]->latitud, $sucursales[$i]->longitud);
        }

      
        $current = Carbon::now('America/La_Paz');
        $horaActual = $current->hour;
      
        $minutoActual = $current->minute;
        $sucursalesAbiertas = array();
        $sucursalesCerradas = array();
        $nombreEntidades = array();
      
        for ($i=0; $i < count($sucursales); $i++) { 
        	$horarioA = $horariosAbiertos[$i][0].':'. $horariosAbiertos[$i][1];
        	$horarioC = $horariosCerrados[$i][0].':'.$horariosCerrados[$i][1];
        	
        	if($this->estaAbierto($horaActual, $horariosAbiertos[$i][0], $horariosCerrados[$i][0],$minutoActual,$horariosAbiertos[$i][1], $horariosCerrados[$i][1]))
        			$sucursalesAbiertas[] = ['nombre' => DB::table('entidades')->where('id', $sucursales[$i]->entidad_id)->select('nombre')->get()[0]->nombre, 'horarioAbierto' => $horarioA, 'horarioCerrado' => $horarioC, 'latitud' => $latitudes[$i], 'longitud' => $longitudes[$i], 'imagen' => 'abierto.png', 'id' => $i, 'distancia' => $distancias[$i]];

        	else
        				$sucursalesCerradas[] = ['nombre' => DB::table('entidades')->where('id', $sucursales[$i]->entidad_id)->select('nombre')->get()[0]->nombre, 'horarioAbierto' => $horarioA, 'horarioCerrado' => $horarioC, 'latitud' => $latitudes[$i], 'longitud' => $longitudes[$i], 'imagen' => 'cerrado.png', 'id' => $i, 'distancia' => $distancias[$i]];
        

        }
        usort($sucursalesCerradas, function($a, $b)
			{
			    if ($a['distancia'] == $b['distancia']) {
			        return 0;
			    }
			    return ($a['distancia'] > $b['distancia']) ? 1 : -1;
			});
        usort($sucursalesAbiertas, function($a, $b)
			{
			    if ($a['distancia'] == $b['distancia']) {
			        return 0;
			    }
			    return ($a['distancia'] > $b['distancia']) ? 1 : -1;
			});
        
        return view('mapa',['Abierto' =>$sucursalesAbiertas,'Cerrado' => $sucursalesCerradas, 'resultado' => 'Resultado de: '.$palabras]); 
    }
        
    	 $sucursalesCerradas = array();
    	 $sucursalesAbiertas = array();
    	  return view('mapa',['Abierto' =>$sucursalesAbiertas,'Cerrado' => $sucursalesCerradas, 'resultado' => 'No se hallaron resultados']); 
    }
    
    private function getDistanceInMetersTo($lat1, $long1, $lat2, $long2){ 

		$degtorad = 0.01745329; 
		$radtodeg = 57.29577951; 

		$dlong = ($long1 - $long2); 
		$dvalue = (sin($lat1 * $degtorad) * sin($lat2 * $degtorad)) 
		+ (cos($lat1 * $degtorad) * cos($lat2 * $degtorad) 
		* cos($dlong * $degtorad)); 

		$dd = acos($dvalue) * $radtodeg; 

		$miles = ($dd * 69.16); 
		$km = ($dd * 111.302) * 1000; 
		$result = explode(".", $km); 		
		return $result[0];  
	} 
}
