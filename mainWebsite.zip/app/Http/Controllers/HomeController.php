<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Contracts\Auth\Guard;
use App\Diagrama;
use App\Sala;
use App\SalaUser;
use App\HistorialDiagrama;
use App\Chat;
use App\ChatHistorial;
class HomeController extends Controller
{
    protected $auth;
   
     public function __construct(Guard $auth)
    {
        $this->middleware('auth');
         $this->auth = $auth;
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('usuario');
    }
    public function nuevasala(){
        return view('crearsala');
    }
    public function createSala(){
        $nombre = $this->auth->user()->name;
        
        Diagrama::create([
            'code' => '',
            
        ]);
        $diagrama = DB::table('diagrama')->select('*')->get();
        $l = count($diagrama);
        $diagrama = $diagrama[$l-1];

        $nombreSala = $_POST['name'];
        Sala::create([
            'nombre' => $nombreSala,
            'diagrama_id' => $diagrama->id
        ]);

        $salaid = DB::table('sala')->select('*')->get();
        $l = count($salaid);
        $salaid = $salaid[$l-1];

        SalaUser::create([
            'sala_id' => $salaid->id,
            'user_id' => $this->auth->user()->id
        ]);

        HistorialDiagrama::create([
            'diagrama_id' => $diagrama->id,
            'user_id' => $this->auth->user()->id,
            'code' => 'Creación de la sala'
        ]);
        Chat::create([
            'sala_id' => $salaid->id
        ]);
        return view('sala', ['nombre' => $nombre, 'salaid' => $salaid->id, 'userid' => $this->auth->user()->id, 'chatid' => $salaid->id, 'code' => 'actor Barroso']);
    }

    public function showSalas(){
        $nombre = $this->auth->user()->name;
        $id = $this->auth->user()->id;
        $salasUser = DB::table('salauser')->where('user_id', $id)->select('sala_id')->get();        
        $result = array();
        foreach ($salasUser as $salita) {
            $salanombre = DB::table('sala')->where('id', $salita->sala_id)->select('*')->get()[0];
           $result[] = ['sala_id' => $salita->sala_id, 'sala_nombre' => $salanombre->nombre, 'fecha' => $salanombre->created_at, 'estado' => $salanombre->estado];
        }
        return view('listasalas', ['nombre' => $nombre, 'userid' => $this->auth->user()->id, 'salas' => $result]);
    }

    public function viewSala(){
        $code = DB::table('diagrama')->where('id', $_POST['sala_id'])->select('code')->get()[0];

        return view('sala', ['nombre' => $_POST['nombre'], 'salaid' => $_POST['sala_id'],'userid' => $_POST['user_id'], 'code' => $code->code]);
    }
    public function añadiruser(){
        $nombre = $this->auth->user()->name;
        $id = $this->auth->user()->id;
        $salasUser = DB::table('salauser')->where('user_id', $id)->select('sala_id')->get();        
        $result = array();
        foreach ($salasUser as $salita) {
            $salanombre = DB::table('sala')->where('id', $salita->sala_id)->select('*')->get()[0];
           $result[] = ['sala_id' => $salita->sala_id, 'sala_nombre' => $salanombre->nombre, 'fecha' => $salanombre->created_at, 'estado' => $salanombre->estado];
        }
        

        return view('adduser', ['nombre' => $nombre, 'userid' => $this->auth->user()->id, 'salas' => $result]);
    }
    public function insertmensaje(Request $request){
        ChatHistorial::create([
            'chat_id' => $request->input('salaid'),
            'user_id' => $request->input('userid'),
            'mensaje' => $request->input('mensaje')
        ]);
        $resultado = ''.$request->input('usuario').': '.$request->input('mensaje');
        return $resultado;
    }
    public function logs(){
       
        $historial = DB::table('chathistorial')->where('chat_id',$_POST['salaid'])->select('*')->get();
        $A = '';
        foreach ($historial as $his) {
            $user = DB::table('users')->where('id',$his->user_id)->select('name')->get()[0];
            $A = $A . $user->name .': '. $his->mensaje .PHP_EOL;
        }
        return $A;
    }


    // DIAGRAMA
    public function previsualizarDiagrama(){
        return view('diagrama/diagrama', ['code' => $_POST['code']]);
    }
    public function getDiagrama(){
        $code = DB::table('diagrama')->where('id', $_POST['salaid'])->select('code')->get()[0];
        return view('diagrama/diagrama', ['code' => $code->code]);
    }
    public function grabarDiagrama(){
        $actual = DB::table('diagrama')->where('id', $_POST['salaid'])->select('actual')->get()[0];
        $actual = $actual->actual + 1;
        DB::table('diagrama')
            ->where('id', $_POST['salaid'])
            ->update(['code' =>$_POST['code'] , 'actual' => $actual]);
         HistorialDiagrama::create([
            'diagrama_id' => $_POST['salaid'],
            'user_id' => $this->auth->user()->id,
            'code' => 'Edición: '. $_POST['code']
        ]);
    }
    public function getActual(){
        $actual = DB::table('diagrama')->where('id', $_POST['salaid'])->select('actual')->get()[0];
        return ''.$actual->actual;
    }
    //HISTORIAL
    public function showHistorial(){
        $Historial = DB::table('historialdiagrama')->where('user_id',$this->auth->user()->id)->select('*')->get();
        $r = array();
        foreach ($Historial as $his) {
            $sala = DB::table('sala')->where('id', $his->diagrama_id)->select('nombre')->get()[0]->nombre;
            $r[] = ['nombre' => $sala, 'code' => $his->code, 'fecha' => $his->created_at];
        }
        return view('historial', ['historial' => $r]);
    }

    public function setUser(){
        $usersala = DB::table('salauser')->where('sala_id',$_POST['sala_id'])->select('user_id');
      
      $a = DB::table('users')->whereNotIn('id', $usersala)->select('*')->get();
      return view('setuser',['users' => $a, 'sala_id' => $_POST['sala_id']]);
    }
    public function saveUser(){
         SalaUser::create([
            'sala_id' => $_POST['sala_id'],
            'user_id' => $_POST['user_id']
        ]);
       $usersala = DB::table('salauser')->where('sala_id',$_POST['sala_id'])->select('user_id');
      
      $a = DB::table('users')->whereNotIn('id', $usersala)->select('*')->get();
      return view('setuser',['users' => $a, 'sala_id' => $_POST['sala_id']]);
    }
}
