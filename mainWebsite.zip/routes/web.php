<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Auth::routes();

Route::get('/usuario', 'HomeController@index');
Route::get('/home', 'HomeController@index');
Route::get('/crearsala', 'HomeController@nuevasala');
Route::get('showSalas','HomeController@showSalas');
Route::post('viewSala','HomeController@viewSala');





///CHAT
Route::post('insertmensaje', 'HomeController@insertmensaje');
Route::post('logs','HomeController@logs');



Route::post('createSala', 'HomeController@createSala');
Route::post('encode','HomeController@encode');

//DIAGRAMA
Route::post('previsualizarDiagrama','HomeController@previsualizarDiagrama');
Route::post('grabarDiagrama','HomeController@grabarDiagrama');
Route::post('getDiagrama','HomeController@getDiagrama');
Route::post('getActual', 'HomeController@getActual');

Route::get('historial', 'HomeController@showHistorial');
Route::get('añadiruser', 'HomeController@añadiruser');
Route::post('SetUser','HomeController@setUser');
Route::post('saveUser','HomeController@saveUser');