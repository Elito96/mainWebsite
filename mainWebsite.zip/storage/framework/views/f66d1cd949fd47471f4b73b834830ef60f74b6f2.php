<!DOCTYPE html>
  <html>
    <head>
        <meta charset="utf-8" />
        <title>SmartWork Bolivia</title>

        <!-- mobile settings -->
        <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />
        <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->

        <!-- WEB FONTS : use %7C instead of | (pipe) -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400%7CRaleway:300,400,500,600,700%7CLato:300,400,400italic,600,700" rel="stylesheet" type="text/css" />

        <!-- CORE CSS -->
        <link href="plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

        <!-- THEME CSS -->
        <link href="css/essentials.css" rel="stylesheet" type="text/css" />
        <link href="css/layout.css" rel="stylesheet" type="text/css" />

        <!-- PAGE LEVEL SCRIPTS -->
        <link href="css/header-1.css" rel="stylesheet" type="text/css" />
        <link href="css/color_scheme/green.css" rel="stylesheet" type="text/css" id="color_scheme" />


        <link rel="stylesheet" type="text/css" href="css/default.css" />
        <link rel="stylesheet" type="text/css" href="css/bookblock.css" />
        <!-- custom demo style -->
        <link rel="stylesheet" type="text/css" href="css/demo4.css" />
        <script src="js/modernizr.custom.js"></script>
         <script type="text/javascript">
            function setSearchCoordinates() {
               var  coords =  {
                  lng: "-63.166683122937",
                  lat: "-17.79531687031729"
                };
                
                navigator.geolocation.getCurrentPosition(
                        function (position){
                            coords =  {
                              lng: position.coords.longitude,
                              lat: position.coords.latitude
                        };
                    setMapa(coords);  //pasamos las coordenadas al metodo para crear el mapa
                        var latitude = document.getElementById('lat');
                        var longitude = document.getElementById('lng');
                        latitude.value = coords.lat;
                        longitude.value = coords.lng;
                        }, function(error){console.log(error);}); 
            }
            window.onload = setSearchCoordinates;
        </script>
    </head>

    <body class="enable-animation" onload="setSearchCoordinates();">
        <div id="header" class="sticky clearfix dark">

            <!-- TOP NAV -->
            <header id="topNav">
                <div class="container">

                    <!-- Mobile Menu Button -->
                    <button class="btn btn-mobile" data-toggle="collapse" data-target=".nav-main-collapse">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- BUTTONS -->
                    <ul class="pull-right nav nav-pills nav-second-main">

                        <!-- SEARCH -->
                        <li class="search">
                            <a href="javascript:;">
                                <i class="fa fa-search"></i>
                            </a>
                            <div class="search-box">
                                <form action="search" method="POST">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <div class="input-group">
                                            <input  type ="hidden" id="lat" name="latitude" value="0">
                                            <input type="hidden" id= "lng" name="longitude" value="0">
                                        <input type="text" name="src" placeholder="Search" id="busqueda" class="form-control" />
                                        <span class="input-group-btn">
                                            
                                            <a onclick="openInSameWindow('/Appmapa/')" class="btn btn-green">Search</a>
                                        </span>
                                    </div>
                                </form>
                                
                            </div>
                        </li>
                        <!-- /SEARCH -->

                    </ul>
                    <!-- /BUTTONS -->

                    <!-- Logo -->
                    <a class="logo pull-left" href="index.html">
                        <img src="images/logo.png" alt="" />
                    </a>

                    <!--
                        Top Nav

                        AVAILABLE CLASSES:
                        submenu-dark = dark sub menu
                    -->
                    <div class="navbar-collapse pull-right nav-main-collapse collapse submenu-dark">
                        <nav class="nav-main">

                            <ul id="topMain" class="nav nav-pills nav-main">
                                <li class="dropdown">
                                    <a class="dropdown-toggle" href="/welcome">
                                        Inicio
                                    </a>
                                </li>
                                <li class="dropdown">
                                    <a class="dropdown-toggle" href="/categoriaApp">
                                        Categorias
                                    </a>
                                </li>
                                

                            </ul>

                        </nav>
                    </div>

                </div>
            </header>
            <!-- /Top Nav -->

        </div>
            
    <section class="dark alternate">
        <h2 align="center"> <?php echo e($resultado); ?> </h2>
        <div id="map" style="width:100%;height:400px; border:1px solid black;"></div>
        <br>
        <div class="container">
            
            <?php $__currentLoopData = $Abierto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-group" onclick="trazarRuta(<?php echo e($Ab['latitud']); ?>,<?php echo e($Ab['longitud']); ?>);" name="<?php echo e($Ab['id']); ?>">
            <a  class="list-group-item active text-center">
                <h4 class="list-group-item-heading"><?php echo e($Ab['nombre']); ?></h4>
                <p class="list-group-item-text"><img src="images/<?php echo e($Ab['imagen']); ?>" width="20" height="20"> <?php echo e($Ab['horarioAbierto']); ?> - <?php echo e($Ab['horarioCerrado']); ?> &nbsp; &nbsp; &nbsp; A <?php echo e($Ab['distancia']); ?> metros.</p>

            </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $Cerrado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-group" onclick="trazarRuta(<?php echo e($Ab['latitud']); ?>,<?php echo e($Ab['longitud']); ?>);">
            <a  class="list-group-item active text-center">
                <h4 class="list-group-item-heading"><?php echo e($Ab['nombre']); ?></h4>
                <p class="list-group-item-text"><img src="images/<?php echo e($Ab['imagen']); ?>" width="20" height="20"> <?php echo e($Ab['horarioAbierto']); ?> - <?php echo e($Ab['horarioCerrado']); ?> &nbsp; &nbsp; &nbsp; A <?php echo e($Ab['distancia']); ?> metros.</p>
            </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

            
        </div>

    </section>
    <script>
var marker;          //variable del marcador
var coords = {};    //coordenadas obtenidas con la geolocalización

//Funcion principal
initMap = function () 
{
       
    //usamos la API para geolocalizar el usuario
           coords =  {
              lng: "-63.166683122937",
              lat: "-17.79531687031729"
            };
            
                navigator.geolocation.getCurrentPosition(
                    function (position){
                        coords =  {
                          lng: position.coords.longitude,
                          lat: position.coords.latitude
                        };
                    setMapa(coords);  //pasamos las coordenadas al metodo para crear el mapa
                
             }, function(error){console.log(error);}); 
            //  setMapa(coords);  //pasamos las coordenadas al metodo para crear el mapa
            
           
          
    
}



function setMapa (coords)
{   
      //Se crea una nueva instancia del objeto mapa

      var map = new google.maps.Map(document.getElementById('map'),
      {
        zoom: 15,
        center:new google.maps.LatLng(coords.lat,coords.lng),

      });
     
 
      //Creamos el marcador en el mapa con sus propiedades
      //para nuestro obetivo tenemos que poner el atributo draggable en true
      //position pondremos las mismas coordenas que obtuvimos en la geolocalización
      marker = new google.maps.Marker({
        map: map,
        draggable: false,
        animation: google.maps.Animation.DROP,
        position: new google.maps.LatLng(coords.lat,coords.lng),

      });
      //agregamos un evento al marcador junto con la funcion callback al igual que el evento dragend que indica 
      //cuando el usuario a soltado el marcador
      marker.addListener('click', toggleBounce);
      
}
function trazarRuta(latitude, longitude){
    var directionsDisplay = new google.maps.DirectionsRenderer();
var directionsService = new google.maps.DirectionsService();
    var map = new google.maps.Map(document.getElementById('map'),
      {
        zoom: 15,
        center:new google.maps.LatLng(coords.lat,coords.lng),

      });
        navigator.geolocation.getCurrentPosition(
                    function (position){
                        coords =  {
                          lng: position.coords.longitude,
                          lat: position.coords.latitude
                        };
                   
            
             }, function(error){console.log(error);});
        var l = coords.lat;
        var lo = coords.lng;
        var origen = l,lo;
        var destino = latitude,longitude;
    var request = {
          origin:new google.maps.LatLng(coords.lat,coords.lng),
          destination:new google.maps.LatLng(latitude,longitude),
          travelMode: google.maps.TravelMode.DRIVING
        };
    directionsService.route(request, function(result, status) {
        if (status == google.maps.DirectionsStatus.OK) {
        directionsDisplay.setDirections(result);
        } 
     });
    var directionsDisplay = new google.maps.DirectionsRenderer();
 
        directionsDisplay.setMap(map);
    

}
//callback al hacer clic en el marcador lo que hace es quitar y poner la animacion BOUNCE
function toggleBounce() {
  if (marker.getAnimation() !== null) {
    marker.setAnimation(null);
  } else {
    marker.setAnimation(google.maps.Animation.BOUNCE);
  }
}

function openInSameWindow(evt) {
    var busqueda = document.getElementById('busqueda').value;
    var lat = document.getElementById('lat').value;
    var lng = document.getElementById('lng').value;
    evt = evt + busqueda + '@'+ lat + '@' + lng;
    window.location=evt;
}
</script>

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDsqR658RyN2cJQEWdzwqNlR4GRjuZmwzQ&callback=initMap"></script>
    <script type="text/javascript">var plugin_path = '/plugins/';</script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

                    <!-- SCRIPTS -->
                    <script type="text/javascript" src="/js/scripts.js"></script>
                    <script src="js/jquerypp.custom.js"></script>
                    <script src="js/jquery.bookblock.js"></script>
                   
                  

    </body>



</html>
