<?php $__env->startSection('content'); ?>
<div id="header" class=" clearfix">

           
                <header id="topNav">
                    <div class="container">

                        <button class="btn btn-mobile" data-toggle="collapse" data-target=".nav-main-collapse">
                            <i class="fa fa-bars"></i>
                        </button>

                       
                        <a class="logo pull-left" href="usuario">
                            <img src="images/logo.png" alt=""  width="126px" height="26px" />
                        </a>

                    
                        <div class="navbar-collapse pull-right nav-main-collapse collapse">
                            <nav class="nav-main">

                                <ul id="topMain" class="nav nav-pills nav-main nav-onepage">
                                    <li class=""><!-- HOME -->
                                        <a href="/">
                                            Home
                                        </a>
                                    </li>
                                    <li><!-- FEATURES -->
                                        <a href="showSalas">
                                            Ver mis salas
                                        </a>
                                    </li>
                                     <li>
                                      <a href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();" class="logout">
                                     Cerrar Sesión
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                            <?php echo e(csrf_field()); ?>

                                    </form>

                                    </li> 
                                </ul>

                            </nav>
                        </div>

                    </div>
                </header>
              

            </div>
<section>
    <div class="display-table" >
                    <div class="display-table-cell vertical-align-middle">
                        <div class="container" >
                            <div class="wrapper">
                            <div class="panel panel-default wow fadeInLeft" style="border-style: inset;">
                                <br>
                                
                            <div class="row" style="margin-left: 10px; margin-right: 10px">
                                <div class="col-md-6 wow fadeIn" data-wow-delay="1s" >
                                    <figure class="box-shadow-1">
                                    <a data-toggle="modal" data-target=".bs-example-modal-sm">
                                        <img class="img-responsive" src="images/crearsala.jpg" alt="" />
                                    </a>
                                    </figure>
                                    <br>
                                    <center><h4>Crear nueva sala</h4></center>
                                </div>

                                <div class="col-md-6 wow fadeIn" data-wow-delay="1s">
                                    <figure class="box-shadow-1">
                                    <a href="showSalas">
                                        <img class="img-responsive" src="images/salas.jpg" alt="" />
                                    </a>
                                    </figure>
                                    <br>
                                    <center><h4>Ver mis salas</h4></center>
                                </div>
                          
                            </div>
                            <div class="row" style="margin-left: 10px; margin-right: 10px">
                                <div class="col-md-6 wow fadeIn" data-wow-delay="1s">
                                    <figure class="box-shadow-1">
                                        <a href="añadiruser">
                                        <img class="img-responsive" src="images/add.jpg" alt="" />
                                        </a>
                                    </figure>
                                    <br>
                                    <center><h4>Añadir usuario a sala</h4></center>
                                </div>

                                <div class="col-md-6 wow fadeIn" data-wow-delay="1s">
                                    <figure class="box-shadow-1" >
                                        <a href="historial">
                                        <img class="img-responsive" src="images/historial.jpg" alt="" />
                                    </a>
                                    </figure>
                                    <br>
                                    <center><h4>Ver historial</h4></center>
                                </div>
                          
                            </div>   
                            <center>
                            <div class="row" style="margin-left: 10px; margin-right: 10px">
                               
                                <div class="col-md-6 wow fadeIn" data-wow-delay="1s">
                                    <figure class="box-shadow-1">
                                    
                                            <a href="<?php echo e(route('logout')); ?>"
                                                    onclick="event.preventDefault();
                                                            document.getElementById('logout-form').submit();" class="logout">

                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                                        <?php echo e(csrf_field()); ?>

                                                </form>
                                        <img class="img-responsive" src="images/salir.jpg" alt="">
                                    </a>
                                    </figure>
                                    <br>
                                    <center><h4>Salir</h4></center>
                                </div>
                             
                          
                            </div> 
                            </center>
                        </div>
                        </div>
                    </div>
                
                        </div>
                    </div>

<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">

            <!-- header modal -->
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="mySmallModalLabel">Crear sala</h4>
            </div>

            <!-- body modal -->
            <div class="modal-body">
                <form class="form-horizontal" role="form" method="POST" action="createSala">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                        <label for="name" class="col-md-4 control-label">Nombre de sala</label>

                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                            <?php if($errors->has('name')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    
                                        

                                    <div class="form-group">
                                        <div class="col-md-6 col-md-offset-4">
                                            <button type="submit" class="btn btn-primary">
                                                Crear
                                            </button>
                                        </div>
                                    </div>
                                </form>
            </div>

        </div>
    </div>
</div>
       
                
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>