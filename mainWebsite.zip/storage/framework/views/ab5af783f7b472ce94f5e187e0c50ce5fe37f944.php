<html>
<head>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="jquery_plantuml.js"></script>
<!-- rawdeflate.js is implicity used by jquery_plantuml.js -->
</head>

<body>

<img id="imgurl" uml="<?php echo e($code); ?>">


</body>

</html> 
