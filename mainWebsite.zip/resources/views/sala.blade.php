@extends('layouts.sala')

@section('content')

<script>

    function submitChat(){
        if(form1.mensaje.value == '')
            return;
        var usuario = form1.usuario.value;
        var mensaje = form1.mensaje.value;
        var userid = form1.userid.value;
        var salaid = form1.salaid.value;
        form1.mensaje.value = '';
        $.post('/insertmensaje',{
             _token: $('meta[name=csrf-token]').attr('content'),
                 usuario: ''+usuario,
                 mensaje: ''+mensaje,
                 userid: ''+userid,
                 salaid: ''+salaid
        })
        .done(function(data) {
              
            })
            .fail(function() {
                
            });
         
    }
   
 
    setInterval(
            function(){ 
                var salaid = form1.salaid.value;
            $.post('/logs',{
             _token: $('meta[name=csrf-token]').attr('content'),
                 salaid: ''+salaid,
        })
        .done(function(data) {
                document.getElementById('logs').innerHTML =  data;
            })
            .fail(function() { });   
        }, 2000);

    function generarDiagrama(){
        //$('#diagramaimg').load('/previsualizarDiagrama');
       // return;
        var code = document.getElementById('code').value;
        document.getElementById('btnprev').className = "btn btn-default";
        $.post('/previsualizarDiagrama',{
             _token: $('meta[name=csrf-token]').attr('content'),
                 code: ''+code,
        })
        .done(function(data) {
            var iframe = document.getElementById('diagramaprev');
            var iframedoc = iframe.document;
                if (iframe.contentDocument)
                    iframedoc = iframe.contentDocument;
                else if (iframe.contentWindow)
                    iframedoc = iframe.contentWindow.document;
         
             if (iframedoc){
                 // Put the content in the iframe
                 iframedoc.open();
                 iframedoc.writeln(data);
                 iframedoc.close();
             } else {
                
             }
             document.getElementById('btnprev').className = "btn btn-primary";
            })
            .fail(function() {
                
            });
    }

     setInterval(
     function(){
        var antiguo = form1.antiguo.value;
                $.post('/getActual',{
            _token: $('meta[name=csrf-token]').attr('content'),
                 salaid: ''+form1.salaid.value
        }).done(function(data){
                nuevo = data;
                document.getElementById('nuevo').value =nuevo;

        }).fail();
        var nuevo = form1.nuevo.value;

        if(antiguo == nuevo){
            return;
        }
        else{
            document.getElementById('antiguo').value =nuevo;
        }
        var salaid = form1.salaid.value;
        $.post('/getDiagrama',{
             _token: $('meta[name=csrf-token]').attr('content'),
                 salaid: ''+salaid
        })
        .done(function(data) {
            var iframe = document.getElementById('diagramaimg');
            var iframedoc = iframe.document;
                if (iframe.contentDocument)
                    iframedoc = iframe.contentDocument;
                else if (iframe.contentWindow)
                    iframedoc = iframe.contentWindow.document;
         
             if (iframedoc){
                 // Put the content in the iframe
                 iframedoc.open();
                 iframedoc.writeln(data);
                 iframedoc.close();
             }
             
            })
            .fail(function() {
                
            });
    }, 3000);
    function getDiagrama(){
        var salaid = form1.salaid.value;
        $.post('/getDiagrama',{
             _token: $('meta[name=csrf-token]').attr('content'),
                 salaid: ''+salaid
        })
        .done(function(data) {
            var iframe = document.getElementById('diagramaimg');
            var iframedoc = iframe.document;
                if (iframe.contentDocument)
                    iframedoc = iframe.contentDocument;
                else if (iframe.contentWindow)
                    iframedoc = iframe.contentWindow.document;
         
             if (iframedoc){
                 // Put the content in the iframe
                 iframedoc.open();
                 iframedoc.writeln(data);
                 iframedoc.close();
             }
             
            })
            .fail(function() {
                
            });
    }
    function grabarDiagrama(){
        var code = document.getElementById('code').value;
        var salaid = form1.salaid.value;
        document.getElementById('btnguardar').className = "btn btn-default";
        $.post('/grabarDiagrama',{
             _token: $('meta[name=csrf-token]').attr('content'),
                 code: ''+code,
                 salaid: ''+salaid
        })
        .done(function(data) {
             document.getElementById('btnguardar').className = "btn btn-primary";
            })
            .fail(function() {
                
            });
    }
</script>
<div id="header" class="  dark clearfix">

           
                <header id="topNav">
                    <div class="container">

                        <button class="btn btn-mobile" data-toggle="collapse" data-target=".nav-main-collapse">
                            <i class="fa fa-bars"></i>
                        </button>

                       
                        <a class="logo pull-left" href="usuario">
                            <img src="images/logo.png" alt=""  width="126px" height="26px" />
                        </a>

                    
                        <div class="navbar-collapse pull-right nav-main-collapse collapse">
                            <nav class="nav-main">

                                <ul id="topMain" class="nav nav-pills nav-main nav-onepage">
                                    <li class=""><!-- HOME -->
                                        <a href="/">
                                            Home
                                        </a>
                                    </li>
                                    <li><!-- FEATURES -->
                                        <a href="usuario">
                                            Menu principal
                                        </a>
                                    </li>
                                     <li>
                                      <a href="{{ route('logout') }}"
                                        onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();" class="logout">
                                     Cerrar Sesión
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                                            {{ csrf_field() }}
                                    </form>

                                    </li> 
                                </ul>

                            </nav>
                        </div>

                    </div>
                </header>
              

            </div>
<section>
    <div class="container">

                    <div class="row" style="border-style: outset;">


                        <!-- CENTER -->
                        <div class="col-md-6"  >
                            <hr />
                             <h4 class="page-header margin-bottom-60 size-20">
                                  <span> Codigo</span>
                                </h4>
                            <div>
                                <br>

                                
                                    {{ csrf_field() }}
                                <!-- comment item -->
                                <textarea id="code" style="width: 100%; overflow-y: scroll; height: 300px;" >{{$code}}</textarea>
                                <br>
                                <br>
                                <center>
                                    <a class="btn btn-primary" id="btnprev" onclick="generarDiagrama();"> Previsualizar </a>
                                
                                <a class="btn btn-primary" id="btnguardar" onclick="grabarDiagrama();">Guardar</a>
                                </center>
                              <br>
                                
                                     
                                


                                <!-- comment item -->
                            </div>
                            
                            
                            
                            

                        </div>

                        <!-- RIGHT -->
                        <div class="col-md-6 hiddex-xs" style="" >
                            <hr />
                            
                            <h4 class="page-header margin-bottom-60 size-20" style="margin-left: 5px;">
                                  <span> Chat</span>
                            </h4>
                            <form name="form1">
                            <div id="logs" class="comments" style="overflow-y: scroll; height: 200px; margin-left: 10px;white-space: pre-line; white-space: pre-wrap; color: blue;" >
                                <font size="5">
                                Cargando mensajes...
                                <!-- comment item -->
                                
                                
                                </font>
                                <!-- comment item -->
                            </div>
                                <br>
                                {{ csrf_field() }}
                                <input type="text" name="usuario" hidden="true" value="{{$nombre}}">
                                <input type="text" name="mensaje" style="margin-left: 5px;">
                                <input type="text" name="salaid" hidden="true" value="{{$salaid}}">
                                <input type="text" name="userid" hidden="true" value="{{$userid}}">
                                <input type="text" name="antiguo" hidden="true" value="-1" id="antiguo">
                                <input type="text" name="nuevo" hidden="true" id="nuevo">
                                <a onclick="submitChat()" class="btn btn-default">Enviar </a>
                               
                            
                             </form>
                             <br>
                             <br>
                        </div>

                    </div>
                    <div class="row" style="border-style: outset;">
                        <div class="col-md-6" style="border-style: outset;">
                            <h4 class="page-header margin-bottom-60 size-20">
                                   <span>Diagrama Previsualización</span>
                                </h4>
                            <div>
                            <iframe id="diagramaprev" src="about:blank"  height="400px" style="width: 100%;">
                             </iframe>
                            </div>
                        </div>

                        <div class="col-md-6" style="border-style: outset;">
                            <h4 class="page-header margin-bottom-60 size-20">
                                   <span>Diagrama</span>
                                </h4>
                            <div>
                            <iframe id="diagramaimg" src="about:blank" height="400px" style="width: 100%;">
                             </iframe>
                            </div>
                        </div>
                    </div>






    </div>
</section>

@endsection
