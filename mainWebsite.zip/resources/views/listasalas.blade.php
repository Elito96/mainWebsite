@extends('layouts.dashboard')

@section('content')
<div id="header" class=" clearfix">

           
                <header id="topNav">
                    <div class="container">

                        <button class="btn btn-mobile" data-toggle="collapse" data-target=".nav-main-collapse">
                            <i class="fa fa-bars"></i>
                        </button>

                       
                        <a class="logo pull-left" href="usuario">
                            <img src="images/logo.png" alt=""  width="126px" height="26px" />
                        </a>

                    
                        <div class="navbar-collapse pull-right nav-main-collapse collapse">
                            <nav class="nav-main">

                                <ul id="topMain" class="nav nav-pills nav-main nav-onepage">
                                    <li class=""><!-- HOME -->
                                        <a href="/">
                                            Home
                                        </a>
                                    </li>
                                    <li><!-- FEATURES -->
                                        <a href="usuario">
                                            Menu Principal
                                        </a>
                                    </li>
                                     <li>
                                      <a href="{{ route('logout') }}"
                                        onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();" class="logout">
                                     Cerrar Sesión
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                                            {{ csrf_field() }}
                                    </form>

                                    </li> 
                                </ul>

                            </nav>
                        </div>

                    </div>
                </header>
              

            </div>
<section>
    <div class="display-table" >
                    <div class="display-table-cell vertical-align-middle">
                        <div class="container" >
                            <div class="wrapper">

                            <div class="panel panel-default wow fadeInLeft" style="border-style: inset;">
                                <br>
                             <center><h2><span>Tus salas</span>   </h2></center>
                            <div class="table-responsive" style="padding-left: 10px; padding-right: 10px;">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <center><th> Nombre de sala</th></center>
                                            <th>Fecha de creación</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($salas as $sala)
                                        <form class="form" method="POST" action="viewSala">
                                            {{ csrf_field() }}
                                        <tr>
                                            <td><i class="ico-bordered ico-hover-dark et-edit"></i>{{$sala['sala_nombre']}}</td>
                                            <td>{{$sala['fecha']}}</td>
                                            <td><button class="btn btn-default" type="submit"> Ingresar a sala</button></td>
                                            <input type="text" name="sala_id" hidden="true" value="{{$sala['sala_id']}}">
                                            <input type="text" name="user_id" hidden="true" value="{{$userid}}">
                                            <input type="text" name="nombre" hidden="true" value="{{$nombre}}">
                                        </tr>
                                        </form>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            </div>
                
                        </div>
                    </div>

<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">

            <!-- header modal -->
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="mySmallModalLabel">Crear sala</h4>
            </div>

            <!-- body modal -->
            <div class="modal-body">
                <form class="form-horizontal" role="form" method="POST" action="createSala">
                                    {{ csrf_field() }}

                                    <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                                        <label for="name" class="col-md-4 control-label">Nombre de sala</label>

                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required autofocus>

                                            @if ($errors->has('name'))
                                                <span class="help-block">
                                                    <strong>{{ $errors->first('name') }}</strong>
                                                </span>
                                            @endif
                                        </div>
                                    </div>

                                    
                                        

                                    <div class="form-group">
                                        <div class="col-md-6 col-md-offset-4">
                                            <button type="submit" class="btn btn-primary">
                                                Crear
                                            </button>
                                        </div>
                                    </div>
                                </form>
            </div>

        </div>
    </div>
</div>
       
                
</section>
@endsection
