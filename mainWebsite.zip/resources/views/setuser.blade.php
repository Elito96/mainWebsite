@extends('layouts.dashboard')

@section('content')
<div id="header" class=" clearfix">

           
                <header id="topNav">
                    <div class="container">

                        <button class="btn btn-mobile" data-toggle="collapse" data-target=".nav-main-collapse">
                            <i class="fa fa-bars"></i>
                        </button>

                       
                        <a class="logo pull-left" href="usuario">
                            <img src="images/logo.png" alt=""  width="126px" height="26px" />
                        </a>

                    
                        <div class="navbar-collapse pull-right nav-main-collapse collapse">
                            <nav class="nav-main">

                                <ul id="topMain" class="nav nav-pills nav-main nav-onepage">
                                    <li class=""><!-- HOME -->
                                        <a href="/">
                                            Home
                                        </a>
                                    </li>
                                    <li><!-- FEATURES -->
                                        <a href="usuario">
                                            Menu Principal
         
                                        </a>
                                    </li>
                                     <li>
                                      <a href="{{ route('logout') }}"
                                        onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();" class="logout">
                                     Cerrar Sesión
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                                            {{ csrf_field() }}
                                    </form>

                                    </li> 
                                </ul>

                            </nav>
                        </div>

                    </div>
                </header>
              

            </div>
<section>
    <div class="display-table" >
                    <div class="display-table-cell vertical-align-middle">
                        <div class="container" >
                            <div class="wrapper">

                            <div class="panel panel-default wow fadeInLeft" style="border-style: inset;">
                                <br>
                             <center><h2><span>Añadir usuario</span>   </h2></center>
                            <div class="table-responsive" style="padding-left: 10px; padding-right: 10px;">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <center><th> Nombre de usuario</th></center>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($users as $user)
                                        <form class="form" method="POST" action="saveUser">
                                            {{ csrf_field() }}
                                        <tr>
                                            <td><i class="ico-bordered ico-hover-dark et-edit"></i>{{$user->name}}</td>
                            
                                            <td><button class="btn btn-default" type="submit"> Añadir usuario</button></td>
                                            <input type="text" name="sala_id" hidden="true" value="{{$sala_id}}">
                                            <input type="text" name="user_id" hidden="true" value="{{$user->id}}">
                                            
                                        </tr>
                                        </form>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            </div>
                
                        </div>
                    </div>

      
             
</section>
@endsection
