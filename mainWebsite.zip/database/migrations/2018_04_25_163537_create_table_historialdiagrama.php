<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableHistorialdiagrama extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('historialdiagrama', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('diagrama_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->string('code');
            $table->timestamps();

            $table->foreign('diagrama_id')->references('id')->on('diagrama')
                ->onUpdate('cascade')
                ->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');   
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('historialdiagrama');
    }
}
